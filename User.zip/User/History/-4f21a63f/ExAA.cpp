#include <iostream>
#include <bitset>
#include <string>
#include <limits>

void mostrarBits(unsigned int n, const std::string& label = "") {
    std::cout << label << std::bitset<8>(n) << " (" << n << ")\n";
}

int main() {
    unsigned int a, b;
    int opcion;

    std::cout << "=== Calculadora Bit a Bit (C++20) ===\n";
    std::cout << "Ingresa el primer número (a): ";
    std::cin >> a;

    std::cout << "\nSelecciona la operación:\n"
              << "1. AND (&)\n"
              << "2. OR (|)\n"
              << "3. XOR (^)\n"
              << "4. NOT (~a)\n"
              << "5. SHIFT LEFT (a << n)\n"
              << "6. SHIFT RIGHT (a >> n)\n"
              << "Opción: ";
    std::cin >> opcion;

    unsigned int resultado;

    if (opcion >= 1 && opcion <= 3) {
        std::cout << "Ingresa el segundo número (b): ";
        std::cin >> b;
    }

    int n;
    switch (opcion) {
        case 1:
            resultado = a & b;
            mostrarBits(a, " a = ");
            mostrarBits(b, " b = ");
            mostrarBits(resultado, "a & b = ");
            break;
        case 2:
            resultado = a | b;
            mostrarBits(a, " a = ");
            mostrarBits(b, " b = ");
            mostrarBits(resultado, "a | b = ");
            break;
        case 3:
            resultado = a ^ b;
            mostrarBits(a, " a = ");
            mostrarBits(b, " b = ");
            mostrarBits(resultado, "a ^ b = ");
            break;
        case 4:
            resultado = ~a;
            mostrarBits(a, " a = ");
            mostrarBits(resultado, "~a = ");
            cout << resultado << endl;
            break;
        case 5:
            std::cout << "Ingresa cantidad de bits a desplazar (n): ";
            std::cin >> n;
            resultado = a << n;
            mostrarBits(a, " a = ");
            mostrarBits(resultado, "a << n = ");
            break;
        case 6:
            std::cout << "Ingresa cantidad de bits a desplazar (n): ";
            std::cin >> n;
            resultado = a >> n;
            mostrarBits(a, " a = ");
            mostrarBits(resultado, "a >> n = ");
            break;
        default:
            std::cerr << "Opción inválida.\n";
            return 1;
    }

    std::cout << "=====================================\n";
    return 0;
}